"""
python v3.7.9
@Project: hotpot
@File   : __init__.py.py
@Author : Zhiyuan Zhang
@Date   : 2023/3/20
@Time   : 2:43
"""
import os
import sys

sys.path.append(os.path.abspath(os.path.dirname(__file__)))
